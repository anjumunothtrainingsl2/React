import React from 'react'

class Footer extends React.Component {
    render() {
        return (
            <React.Fragment>
                <div>Copyrights 2021</div>
                <div>Developed by Anju Munoth</div>
            </React.Fragment>
        );
    }
}

export default Footer;