import React from "react"
import walmart from "./walmart.jpeg";
class Home extends React.Component {
    render() {
        var productsArray = [
            { productName: "Iphone", price: 68787, imageUrl: "./iphoneXR.jpg" },
            { productName: "Samsung", price: 90908, imageUrl: "./samsung note9.png" },
            { productName: "One Plus", price: 36789, imageUrl: "./oneplus6.jpg" },
            { productName: "MI", price: 247678, imageUrl: "./mi note.jpg" }]

        return (
            <React.Fragment>
                <div>Home Component</div>
                <div className="container-fluid">
                    <div className="card-group">
                        <div className="card bg-warning" style={{ width: "18rem" }}>
                            <img src={productsArray[0].imageUrl} className="card-img-top" />
                            <div className="card-body">
                                <h2 className="card-title">{productsArray[0].productName}</h2>
                                <p className="card-text">Price : Rs.{productsArray[0].price}</p>
                                <input type="button" value="Add To Cart" className="btn btn-primary" />
                            </div>
                        </div>
                        <div className="card bg-warning" style={{ width: "18rem" }}>
                            <img src={productsArray[1].imageUrl} className="card-img-top" />
                            <div className="card-body">
                                <h2 className="card-title">{productsArray[1].productName}</h2>
                                <p className="card-text">Price : Rs.{productsArray[1].price}</p>
                                <input type="button" value="Add To Cart" className="btn btn-primary" />
                            </div>
                        </div>
                        <div className="card bg-warning" style={{ width: "18rem" }}>
                            <img src={productsArray[2].imageUrl} className="card-img-top" />
                            <div className="card-body">
                                <h2 className="card-title">{productsArray[2].productName}</h2>
                                <p className="card-text">Price : Rs.{productsArray[2].price}</p>
                                <input type="button" value="Add To Cart" className="btn btn-primary" />
                            </div>
                        </div>
                        <div className="card bg-warning" style={{ width: "18rem" }}>
                            <img src={productsArray[3].imageUrl} className="card-img-top" />
                            <div className="card-body">
                                <h2 className="card-title">{productsArray[3].productName}</h2>
                                <p className="card-text">Price : Rs.{productsArray[3].price}</p>
                                <input type="button" value="Add To Cart" className="btn btn-primary" />
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>

        );
    }
}

export default Home;