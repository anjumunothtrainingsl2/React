import logo from './logo.svg';
import './App.css';
import walmart from "./walmart.jpeg"
import Menu from "./Menu";
import Home from './Home';
import Footer from "./Footer";

function App() {
  // return VIRTUAL DOM in jsx
  var borderImg={border:"5px solid blue"}

  return (
    <div className="App">
      <div id="headerDiv">
       <img src={walmart} alt="logo of walmart" style={borderImg} id="logoImg"/>
      </div>
      <Menu></Menu>
      <Home></Home>
      <Footer></Footer>

    </div>
  );
}

export default App;
