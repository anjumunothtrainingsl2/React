import React from 'react'
import logo from './logo.svg';
import './App.css';
import walmart from "./walmart.jpeg"
import Menu from "./Menu";
import Home from './Home';
import Footer from "./Footer";

class App extends React.Component {
  // return VIRTUAL DOM in jsx
  borderImg={border:"5px solid blue"}
  constructor()
  {
    super();
    this.state={cartArr:[]}
  }
  sendConfirmedProductToAppEventHandler=(obj)=>{
    console.log("In app component confirmed product",obj)
    /* this.setState({cartArr:obj});// wrong; cartArr will become an object
    this.setState({cartArr:this.state.cartArr.push(obj)});// wrong ; immutability
    this.setState({cartArr:[...this.state.cartArr,obj]});// correct best way -- no
     */
    this.setState((state,props)=>{
      return({cartArr:[...state.cartArr,obj]});
    },()=>{
      console.log("Cart Array",this.state.cartArr)
    })
    // setState -- async; 

  }
  render()
{  return (
    <div className="App">
      <div id="headerDiv">
       <img src={walmart} alt="logo of walmart" style={this.borderImg} id="logoImg"/>
      </div>
      <input type="button" value="Show Cart"></input>
      <Menu></Menu>
      <Home sendConfirmedProductToApp={this.sendConfirmedProductToAppEventHandler}></Home>
      {/* <DisplayCart ></DisplayCart> */}
      <Footer></Footer>

    </div>
  );
}
}

export default App;
