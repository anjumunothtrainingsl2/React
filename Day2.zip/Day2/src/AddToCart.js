import React from "react"

class AddToCart extends React.Component {
    constructor(props) {
        super(props)
        this.state = { quantityPurchased: 1 }
    }

    componentWillUnmount()
    {
        console.log("ADd to cart unmounted");
    }
    changeQuantityEventHandler = (str1) => {
        if (str1 == "dec") {
            if (this.state.quantityPurchased > 1) {
                this.setState({ quantityPurchased: this.state.quantityPurchased - 1 })
            }
        }
        else {
            if (this.state.quantityPurchased < this.props.cartProdToBeAdded.quantity) {
                this.setState({ quantityPurchased: this.state.quantityPurchased + 1 })
            }
        }
    }
    confirmCartEventHandler=()=>{
        alert("Thank for adding to the cart");
        var confirmedProduct={...this.props.cartProdToBeAdded,quantityPurchased:this.state.quantityPurchased}
        console.log("Confirmed Product",confirmedProduct)
        // trigger a custom event and embed the data as part of the event
        this.props.sendConfirmedProduct(confirmedProduct);


    }
    render() {
        return (
            <React.Fragment>
                <h1>Add to Cart Component</h1>
                <div key={this.props.cartProdToBeAdded.productId} className="card bg-warning" style={{ width: "20rem" }}>
                    <img src={this.props.cartProdToBeAdded.imageUrl} className="card-img-top" style={{ width: "100px", height: "100px" }} />
                    <div className="card-body">
                        <h2 className="card-title">{this.props.cartProdToBeAdded.productName}</h2>
                        <p className="card-text">Price : Rs.{this.props.cartProdToBeAdded.price}</p>
                        <p className="card-text">Quantity : {this.props.cartProdToBeAdded.quantity}</p>
                        <input type="button" value="-" onClick={this.changeQuantityEventHandler.bind(this, "dec")} disabled={this.state.quantityPurchased <=1} />
                        {this.state.quantityPurchased}
                        <input type="button" value="+" onClick={this.changeQuantityEventHandler.bind(this, "inc")} disabled={this.state.quantityPurchased >=this.props.cartProdToBeAdded.quantity}/>
                        <br />
                        <input type="button" value="Confirm to the Cart" className="btn btn-primary" onClick={this.confirmCartEventHandler}/>
                    </div>
                </div>

            </React.Fragment>);

    }
}

export default AddToCart;