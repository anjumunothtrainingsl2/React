//Create a React class component called as MENU
import React from "react";

class Menu extends React.Component
{
    // overriding render method
    render()
    {
        return(
            <h1>Menu</h1>
        );
    }
}

export default Menu;