import React from 'react'

function Payments(props) {
    console.log("Props in Payments",props)
    var cartArr=props.location.state.cartArr;
    var totalAmount=0;
    for(var i=0;i<cartArr.length;i++)
    {
        totalAmount+=(cartArr[i].price*cartArr[i].quantityPurchased)
    }
    return (
        <React.Fragment>
        <h1>Payments Component</h1>
        <h2> Total Bill Amount {totalAmount}</h2>
        </React.Fragment>

    );
}

export default Payments;