// Hooks
//React 16.8 functional components ; add state to functional components
//1. add state to the functional components
//2. replicate the various lifecycle methods 

import React,{useState,useEffect,useRef} from 'react'
import axios from "axios"

function UsersList(props)
{
    var nameRef=useRef()
    var [numberOfEntries,setNumberOfEntries]=useState(0);
    var [name,setName]=useState("");
    var [usersList,setUsersList]=useState([]);
    /* var arr1=useState("");
    var numberOfEntries=arr1[0]
    var setNumberOfEntries=arr1[1] */
    var onChangeTextEventHandler=(event)=>{
        console.log(event.target.value)
        setNumberOfEntries(event.target.value);
        // implicitly call the render method ;; similar to setState
    }
    var onChangeNameEventHandler=(event)=>{
        console.log(event.target.value)
        setName(event.target.value);
        // implicitly call the render method ;; similar to setState
    }

    useEffect(()=>{
        
        // [] as the second param --- called once
        console.log("Sending the request to the API")
        // get method will return a promise;
        // promise resolved --- then will be excuted
        //promise rejected -- catch will be excuted
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((response)=>{
            console.log(response.data)
            setUsersList(response.data);
        })
        .catch((err)=>{console.log("Error")})

    },[])
    useEffect(()=>{
        // called each time the component is rendered;
        console.log("Called everytime the componnet is rendered")
    })

    useEffect(()=>{
        // called each time the component is rendered and the value of name is going to change;
        console.log("Name changed")
    },[name])

    useEffect(()=>{
        // called each time the component is rendered;
        console.log("Called everytime the props changes")
    },[props])

    return(
        <React.Fragment>
            <input type="text" onChange={onChangeTextEventHandler} placeholder="Number of Entries"/>
            <input type="text" onChange={onChangeNameEventHandler} placeholder="Enter ur last name" />
            <input type="button" value="Get Entries" />
            <br /> Number of Entries{numberOfEntries}
            <br/> Name: {name}
            <br/>Number of Users:{usersList.length}
        </React.Fragment>
        )
}
export default UsersList