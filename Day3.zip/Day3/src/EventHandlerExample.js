import React from "react"
import walmart from "./walmart.jpeg";
class Home extends React.Component {
    constructor()
    {
        super();
        this.button1Clickhandler=this.button1Clickhandler.bind(this);
    }
    addToCartEventHandler(pId)
    {
        console.log("Add to Cart button clicked with productId"+pId)
    }
    button1Clickhandler()
    {
        console.log("Button 1 clicked")
        // this --> input type button element; but now point to the component 
        this.addToCartEventHandler(100)
    }
    button2Clickhandler=()=>
    {
        // this -- lexical scope; parent scope
        console.log("Button 2 clicked")
        this.addToCartEventHandler(200)
    }
    button3Clickhandler()
    {
        console.log("Button 3 clicked")
        this.addToCartEventHandler(300)
    }
    render() {
        var productsArray = [
            {productId:1, productName: "Iphone", price: 68787, imageUrl: "./iphoneXR.jpg", quantity: 10, description: "IPhone XR series" },
            {productId:2, productName: "Samsung", price: 90908, imageUrl: "./samsung note9.png", quantity: 15, description: "Samsung Note 9" },
            { productId:3,productName: "One Plus", price: 36789, imageUrl: "./oneplus6.jpg", quantity: 12, description: "One Plus 6" },
            { productId:4,productName: "MI", price: 247678, imageUrl: "./mi note.jpg", quantity: 3, description: "MI NOTE 5" }];

        var divArray = productsArray.map((item) => {
            return (
                <div className="card bg-warning" style={{ width: "20rem" }}>
                    <img src={item.imageUrl} className="card-img-top" style={{width:"100px",height:"100px"}} />
                    <div className="card-body">
                        <h2 className="card-title">{item.productName}</h2>
                        <p className="card-text">Price : Rs.{item.price}</p>
                        <p className="card-text">Quantity : {item.quantity}</p>
                        <input type="button" value="Add To Cart" className="btn btn-primary" onClick={this.addToCartEventHandler.bind(this,item.productId)} />
                    </div>
                </div>)

        })

        return (
            <React.Fragment>
                <div>Home Component</div>
                <div className="container-fluid">
                    <div className="card-group">
                        {divArray}
                    </div>
                </div>
                <input type="button" value="button1" onClick={this.button1Clickhandler}/>
                <input type="button" value="button2" onClick={this.button2Clickhandler}/>
                <input type="button" value="button3" onClick={this.button3Clickhandler.bind(this)}/>
            </React.Fragment>

        );
    }
}

export default Home;