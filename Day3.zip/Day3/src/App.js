import React from 'react'
import { BrowserRouter as Router, Route, Redirect, Switch } from "react-router-dom"

import logo from './logo.svg';
import './App.css';
import walmart from "./walmart.jpeg"
import Menu from "./Menu";
import Home from './Home';
import Footer from "./Footer";
import DisplayCart from "./DisplayCart"
import Payments from './Payments';
import Details from "./Details"
import UsersList from './UsersList';

class App extends React.Component {
  // return VIRTUAL DOM in jsx
  borderImg = { border: "5px solid blue" }
  constructor(props) {
    super(props);
    this.state = { cartArr: [] }
  }
  sendConfirmedProductToAppEventHandler = (obj) => {
    console.log("In app component confirmed product", obj)
    /* this.setState({cartArr:obj});// wrong; cartArr will become an object
    this.setState({cartArr:this.state.cartArr.push(obj)});// wrong ; immutability
    this.setState({cartArr:[...this.state.cartArr,obj]});// correct best way -- no
     */
    this.setState((state, props) => {
      return ({ cartArr: [...state.cartArr, obj] });
    }, () => {
      console.log("Cart Array", this.state.cartArr)
    })
    // setState -- async; 

  }

  render() {
    return (
      <Router>
        <div className="App">
          <div id="headerDiv">
            <img src={walmart} alt="logo of walmart" style={this.borderImg} id="logoImg" />
          </div>
          <Menu></Menu>
          <Switch>
            <Route path="/products" >
              <Home sendConfirmedProductToApp={this.sendConfirmedProductToAppEventHandler}></Home>
            </Route>
            <Route path="/users" component={UsersList}></Route>
            <Route path="/cart"
              render={(props) => {
                return (
                  <DisplayCart cartArr={this.state.cartArr} {...props} ></DisplayCart>
                )
              }
              }
            >
            </Route>
            <Route path="/" exact>
              <Redirect to="/products"></Redirect>
            </Route>
            <Route path="/details/:pId" component={Details} ></Route>
            <Route path="/payments" component={Payments} ></Route>
            <Route render={
              () => {
                return (<h1>Page Not found</h1>)
              }
            } >

            </Route>
          </Switch>
          <Footer></Footer>

        </div>
      </Router>
    );
  }
}

export default App;


