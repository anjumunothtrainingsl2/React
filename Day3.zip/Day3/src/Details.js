import React from 'react'

function Details(props)
{
    console.log(props);
    return (<h1>Details Component of Product With Id : {props.match.params.pId}</h1>)
}
export default Details;