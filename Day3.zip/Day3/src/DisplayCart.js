import React from 'react'

function DisplayCart(props)
{
    var showDetailsEventHandler=(obj)=>{
        props.history.push("/details/"+obj.productId)
    }
     var buyEventhandler=()=>{
        // navigate to Payments Component
        // change the address in the url to /payments;
        // whenever the url is /payments load Payments Component
        // props-- 1:parent to child communication,2:lifting the state up, 3: props -- route info
        // props-- Class, Functional Components
        console.log("Props info",props); 
        // data - cartArr 
        // send data from DisplayCart to Payments Component via routing
        props.history.push("/payments",{cartArr:props.cartArr});  


    }
    console.log("Props info",props);  
    var trArray=props.cartArr.map((item)=>{
        return(
            <tr key={item.productId}>
                <td>
                    <img src={item.imageUrl} alt="Image of product" style={{height:"100px",width:"100px"}} />

                </td>
                <td>
                    {item.productName}
                </td>
                <td>
                    {item.price}
                </td>
                <td>
                    {item.quantityPurchased}
                </td>
                <td>
                    {item.price*item.quantityPurchased}
                </td>
                <td>
                    <input type="button" value="Show Details" onClick={showDetailsEventHandler.bind(this,item)} />
                </td>
            </tr>
        )
    })
    return(
        <React.Fragment>
        <h1>Display Cart Component</h1>
        <table className="table">
            <thead>
                <tr>
                    <th scope="col">Image</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total  </th>
                </tr>
            </thead>
            <tbody>
                {trArray}
                </tbody>
                </table>
                <input type="button" value="Buy" className="btn btn-primary" onClick={buyEventhandler}/>
    </React.Fragment>

    );
}

export default DisplayCart;