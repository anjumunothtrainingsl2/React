import React from "react"
import AddToCart from "./AddToCart";
import walmart from "./walmart.jpeg";
class Home extends React.Component {
    showAddToCart;
    constructor()
    {
        super();
        this.state={showAddToCart:false,productToBeAdded:{},
        productsArray : [
            {productId:1, productName: "Iphone", price: 68787, imageUrl: "./iphoneXR.jpg", quantity: 10, description: "IPhone XR series" },
            {productId:2, productName: "Samsung", price: 90908, imageUrl: "./samsung note9.png", quantity: 15, description: "Samsung Note 9" },
            { productId:3,productName: "One Plus", price: 36789, imageUrl: "./oneplus6.jpg", quantity: 12, description: "One Plus 6" },
            { productId:4,productName: "MI", price: 247678, imageUrl: "./mi note.jpg", quantity: 3, description: "MI NOTE 5" }]
    };

    }
    addToCartEventHandler(obj)
    {
        console.log("Add to Cart button clicked with productId"+obj.productId);
        // set up a flag
        //this.state.showAddToCart=true;
        // setState -- 1. merge the values with state value and implicitly call the render method again
        this.setState({showAddToCart:true,productToBeAdded:obj})

        
    }
    sendConfirmedProductEventHandler=(obj)=>
    {
        console.log("Confirmed product from ADD CART component",obj)
        this.setState({showAddToCart:false})
        // change the quantity;
        // immutability
        var tempArray=[...this.state.productsArray];
        var pos=tempArray.findIndex((item)=>{
            if(item.productId == obj.productId)
                return true;
        })
        console.log("Position"+pos);
        if(pos >=0)
        {
            tempArray[pos].quantity=tempArray[pos].quantity-obj.quantityPurchased;

        }
        this.setState({productsArray:tempArray})
        this.props.sendConfirmedProductToApp(obj);

    }
    render() {
        
        // key should be unique among its own siblings; key is going be distinguishing factor    
        var divArray = this.state.productsArray.map((item,index) => {
            return (
                <div key ={item.productId} className="card bg-warning" style={{ width: "20rem" }}>
                    <img src={item.imageUrl} className="card-img-top" style={{width:"100px",height:"100px"}} />
                    <div className="card-body">
                        <h2 className="card-title">{item.productName}</h2>
                        <p className="card-text">Price : Rs.{item.price}</p>
                        <p className="card-text">Quantity : {item.quantity}</p>
                        <input type="button" value="Add To Cart" className="btn btn-primary" onClick={this.addToCartEventHandler.bind(this,item)} />
                        
                    </div>
                </div>)

        })

        return (
            <React.Fragment>
                <div>Home Component</div>
                <div className="container-fluid">
                    <div className="card-group">
                        {divArray}
                    </div>
                    {this.state.showAddToCart && <AddToCart cartProdToBeAdded={this.state.productToBeAdded} sendConfirmedProduct={this.sendConfirmedProductEventHandler}></AddToCart>}
                    {/* {showAddToCart ?<AddToCart cartProdToBeAdded={this.state.productToBeAdded}></AddToCart>:null} */}
                </div>
               </React.Fragment>

        );
    }
}

export default Home;